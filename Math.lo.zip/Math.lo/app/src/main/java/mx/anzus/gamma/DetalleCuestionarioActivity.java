package mx.anzus.gamma;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DetalleCuestionarioActivity extends AppCompatActivity {

    Intent lastActivity;
    String mode,user,grupo,cuest;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detallecuestionario);
        lastActivity = getIntent();
        textView = (TextView) findViewById(R.id.id_detalle);
        mode = lastActivity.getStringExtra("MODE");
        user = lastActivity.getStringExtra("TOKEN");
        grupo = lastActivity.getStringExtra("GRUPO");
        cuest = lastActivity.getStringExtra("CUEST");
        ArrayList preguntas = Database.getPreguntasCuestionario(cuest);
        System.out.println(preguntas);
        for(int i =0;i<preguntas.size();i++){
            textView.setText(preguntas.get(i).toString()+"\n");
        }
    }

}
